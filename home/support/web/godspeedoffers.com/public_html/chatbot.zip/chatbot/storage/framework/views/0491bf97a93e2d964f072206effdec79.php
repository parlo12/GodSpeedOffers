<!DOCTYPE html>
<html>
<head>
    <title>The Bot could not answer. Please answer</title>
</head>
<body>
    <p>Click the link below to fill the form and answer the question:</p>
    <p><a href="{<?php echo $url; ?>}">Fill the form</a></p>
</body>
</html>
<?php /**PATH D:\desktop\chatbot\resources\views/emails/answerRequest.blade.php ENDPATH**/ ?>